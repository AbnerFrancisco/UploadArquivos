<?php
echo 'upload_max_filesize: ' . ini_get('upload_max_filesize') . "<hr/>"; 
echo 'max_file_uploads: ' . ini_get('max_file_uploads ') . "<hr/>";
echo 'post_max_size: ' . ini_get('post_max_size ') . "<hr/>";
  