<?php
$limitar_ext = "sim";

$extensoes_autorizadas = array(".gif",".pdf",".jpg",".png");

$caminho_absoluto = "./arquivos";

$tamanho_bytes = "2000000";

$limitar_tamanho = "sim";

$sobrescrever = "nao";
 ?>